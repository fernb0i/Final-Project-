package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Die;

/**
 * Servlet implementation class RollServlet
 */
@WebServlet("/RollServlet")
public class RollServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RollServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			//get inputs 
			int purseValue = Integer.parseInt(request.getParameter("purseValue"));
			int currentRoll = Integer.parseInt(request.getParameter("currentRoll"));
			int fdW = 0;
			int fdL = 0;
			int bgW = 0;
			int bgL = 0;
			int sgW = 0;
			int sgL = 0;
			int smW = 0;
			int smL = 0;
			int tpW = 0;
			int tpL = 0;
			int singleBet = Integer.parseInt(request.getParameter("singleBet"));
			int singleWinnings = 0;
			int singleLosses = 0;
			boolean singleWon = false;
			int optionValue = Integer.parseInt(request.getParameter("optionValue"));
			String singleMsg = "";
			int tripleBet = Integer.parseInt(request.getParameter("tripleBet"));
			int tripleWinnings = 0;
			int tripleLosses = 0;
			boolean tripleWon = false;
			String tripleMsg = "";
			int smallBet = Integer.parseInt(request.getParameter("smallBet"));
			int smallWinnings = 0;
			int smallLosses = 0;
			boolean smallWon = false;
			String smallMsg = "";
			int bigBet = Integer.parseInt(request.getParameter("bigBet"));
			int bigWinnings = 0;
			int bigLosses = 0;
			boolean bigWon = false;
			String bigMsg = "";
			int fieldBet = Integer.parseInt(request.getParameter("fieldBet"));
			int fieldWinnings = 0;
			int fieldLosses = 0;
			boolean fieldWon = false;
			String fieldMsg = "";
			
			//create a random dice roll
			Die die1 = new Die();
			Die die2 = new Die();
			Die die3 = new Die();
				
			//assign dice objects to int values
			int one = die1.getValue();
			int two = die2.getValue();
			int three = die3.getValue();
			int sum = one + two + three;

			//increment 
			currentRoll++;
			
			//check if bets match
				if(optionValue == one) {
					purseValue += singleBet; 
					singleWinnings += singleBet;
					singleWon = true;
				}
				if(optionValue == two) {
					purseValue += singleBet; 
					singleWinnings += singleBet;
					singleWon = true;
				}
				if(optionValue == three) {
					purseValue += singleBet; 
					singleWinnings += singleBet;
					singleWon = true;
				}
				if (optionValue != one && optionValue != two && optionValue != three) {
					purseValue -= singleBet; 
					singleLosses = 0 - singleBet;
					singleWon = false;
				}
				if (singleWon==true) {
					singleMsg = "Single Bet - Winner - Winnings: " + singleWinnings + "."; 
					sgW = singleWinnings;
					sgL = 0;
				}
				if (singleWon == false) {
					singleMsg = "Single Bet - Loser - Losses: " + singleLosses + "."; 
					sgW = 0;
					sgL = singleLosses;
				}
				if(one == two && one == three) {
					tripleWon = true;
					tripleWinnings += tripleBet;
					purseValue += tripleBet;
					tripleMsg = "Triple Bet - Winner - Winnings: " + tripleWinnings + "."; 
					tpW = tripleWinnings;
					tpL = 0;
				}
				if(one != two || one != three){
					tripleWon = false;
					purseValue -= tripleBet; 
					tripleLosses = 0 - tripleBet;
					tripleMsg = "Triple Bet - Loser - Losses: " + tripleLosses + "."; 
					tpW = 0;
					tpL = tripleLosses;
				}
				if(sum <= 10 && tripleWon == false) {
					smallWon = true;
					purseValue += smallBet; 
					smallWinnings = smallBet;
					smallMsg = "Small Bet - Winner - Winnings: " + smallWinnings + "."; 
					smW = smallWinnings;
					smL = 0;	
				}
				if(sum > 10 || (tripleWon == true)) {
					smallWon = false;
					purseValue -= smallBet; 
					smallLosses = 0 - smallBet;
					smallMsg = "Small Bet - Loser - Losses: " + smallLosses + "."; 
					smW = 0;
					smL = smallLosses;
				}
				if(sum >= 11 && tripleWon == false) {
					bigWon = true;
					purseValue += bigBet; 
					bigWinnings = bigBet;
					bigMsg = "Big Bet - Winner - Winnings: " + bigWinnings + "."; 
					bgW = bigWinnings;
					bgL = 0;
				}
				if(sum < 11 || (tripleWon == true)) {
					bigWon = false;
					purseValue -= bigBet; 
					bigLosses = 0 - bigBet;
					bigMsg = "Big Bet - Loser - Losses: " + bigLosses + "."; 
					bgL = bigLosses;
					bgW = 0;
				}
				if(sum < 8 || sum > 12) {
					purseValue += fieldBet; 
					fieldWinnings = fieldBet;
					fieldWon = true;
					fieldMsg = "Field Bet - Winner - Winnings: " + fieldWinnings + "."; 
					fdW = fieldWinnings;
					fdL = 0;
				}
				if(sum >= 8 && sum <= 12) {
					purseValue -= fieldBet; 
					fieldLosses = 0 - fieldBet;
					fieldWon = false;
					fieldMsg = "Field Bet - Loser - Losses: " + fieldLosses + "."; 
					fdL = fieldLosses;
					fdW = 0;
				}
			
				int totalWinnings = fdW + fdL + tpW + tpL + sgW + sgL + smW + smL + bgW + bgL;
				//purseValue = purseValue + totalWinnings;

				
				request.setAttribute("totalWinnings", totalWinnings);
				request.setAttribute("fieldMsg", fieldMsg);
				request.setAttribute("tripleMsg", tripleMsg);	
				request.setAttribute("singleMsg", singleMsg);
				request.setAttribute("smallMsg", smallMsg);
				request.setAttribute("bigMsg", bigMsg);
				request.setAttribute("purseValue", purseValue);
				request.setAttribute("currentRoll", currentRoll);
				request.setAttribute("one", one);
				request.setAttribute("two", two);
				request.setAttribute("three", three);
				
			//send control to next component
			RequestDispatcher rd = request.getRequestDispatcher("/reveal.jsp");
			rd.forward(request,response);
	}

}
